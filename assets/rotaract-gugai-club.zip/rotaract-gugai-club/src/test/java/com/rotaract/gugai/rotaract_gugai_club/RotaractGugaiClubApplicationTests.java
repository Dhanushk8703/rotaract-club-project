package com.rotaract.gugai.rotaract_gugai_club;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RotaractGugaiClubApplicationTests {

	@Test
	void contextLoads() {
	}

}
