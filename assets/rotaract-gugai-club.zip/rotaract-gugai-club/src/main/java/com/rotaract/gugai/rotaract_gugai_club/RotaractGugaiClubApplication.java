package com.rotaract.gugai.rotaract_gugai_club;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RotaractGugaiClubApplication {

	public static void main(String[] args) {
		SpringApplication.run(RotaractGugaiClubApplication.class, args);
	}

}
